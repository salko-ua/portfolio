<script>
  import { asset } from "$app/paths";
</script>

<div
  class="bg-black bg-[url(/background.jpg)] min-h-screen h-max w-screen bg-no-repeat bg-top bg-size-5"
>
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
  <img alt="fuck you" src={asset("/pfp.jpg")} class="h-50 w-50 bg-contain" />
</div>
